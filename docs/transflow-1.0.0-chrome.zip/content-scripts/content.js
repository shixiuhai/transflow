(function(){function e(e){return e}function t(e){let t=e.trim();if(!t||t===`transparent`)return null;let n=t.match(/^#([0-9a-f]{3,8})$/i);if(n){let e=n[1]??``,t=e=>parseInt(e.length===1?e+e:e,16);if(e.length===3||e.length===4)return[t(e[0]),t(e[1]),t(e[2]),e.length===4?t(e[3])/255:1];if(e.length===6||e.length===8)return[parseInt(e.slice(0,2),16),parseInt(e.slice(2,4),16),parseInt(e.slice(4,6),16),e.length===8?parseInt(e.slice(6,8),16)/255:1]}let r=t.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+))?\s*\)$/i);return r?[Number(r[1]),Number(r[2]),Number(r[3]),r[4]===void 0?1:Number(r[4])]:null}function n(e){let t=e/255;return t<=.03928?t/12.92:((t+.055)/1.055)**2.4}function r([e,t,r]){return .2126*n(e)+.7152*n(t)+.0722*n(r)}function i(e,t){let n=r(e),i=r(t),a=Math.max(n,i),o=Math.min(n,i);return(a+.05)/(o+.05)}function a(e,t,n){let r=Math.min(1,Math.max(0,n));return[Math.round(e[0]*r+t[0]*(1-r)),Math.round(e[1]*r+t[1]*(1-r)),Math.round(e[2]*r+t[2]*(1-r)),1]}function o(e){return`rgb(${e[0]}, ${e[1]}, ${e[2]})`}var s=new WeakMap,c=new Map;function l(e){let n=s.get(e);if(n)return n;let r=[],i=e,a=[255,255,255,1];for(;i;){let e=s.get(i);if(e){a=e;break}r.push(i);let n=t(getComputedStyle(i).backgroundColor);if(n&&n[3]>.8){a=n;break}i=i.parentElement}for(let e of r)s.set(e,a);return a}function u(e){let n=l(e),s=t(getComputedStyle(e).color)??[16,20,24,1],u=`${n.join(`,`)}|${s.join(`,`)}`,d=c.get(u);if(d)return d;let f=r(n)<.45,p=a(s,n,.62);i(p,n)<4.5&&(p=a(s,n,.9));let m=f?[45,212,191,1]:[15,118,110,1],h=`rgba(${m[0]}, ${m[1]}, ${m[2]}, ${f?.5:.38})`,g=o(a(m,n,.12)),_={bg:o(n),fg:o(s),dark:f,trans:o(p),rule:h,card:g};return c.size>200&&c.clear(),c.set(u,_),_}function d(e,t){let n=document.documentElement;n.style.setProperty(`--tf-bg`,e.bg),n.style.setProperty(`--tf-fg`,e.fg),n.style.setProperty(`--tf-trans-color`,e.trans),n.style.setProperty(`--tf-rule-color`,e.rule),n.style.setProperty(`--tf-card-bg`,e.card),n.classList.toggle(`tf-dark`,e.dark);for(let e of[`blend`,`card`,`mask`,`replace`])n.classList.toggle(`tf-mode-${e}`,e===t)}var f=`p, li, h1, h2, h3, h4, h5, h6, blockquote, figcaption, dd, dt, td, th, summary`,p=`pre,code,kbd,samp,var,textarea,input,select,option,script,style,noscript,svg,canvas,math,template,[contenteditable]:not([contenteditable="false"]),[translate="no"],.notranslate,[aria-hidden="true"]`;function m(e){return e.replace(/\u00a0/g,` `).replace(/\s+/g,` `).trim()}function h(e){if(e.hidden)return!0;let t=getComputedStyle(e);return t.display===`none`||t.visibility===`hidden`||t.opacity===`0`}function g(e){return/\p{L}/u.test(e)}function _(e={}){let t=e.root??document.body;if(!t)return{blocks:[],totalFound:0};let n=e.maxSegments??2e3,r=Array.from(t.querySelectorAll(f)),i=new Set(r),a=r.filter(e=>{for(let t of Array.from(e.querySelectorAll(f)))if(i.has(t))return!1;return!0}),o=[],s=0;for(let e of a){if(e.closest(p)||e.dataset.tfTranslated===`1`||e.dataset.tfSkip===`1`||e.isContentEditable||h(e))continue;let t=m(e.textContent??``);t.length<2||!g(t)||(s+=1,o.length>=n||o.push({id:`b${o.length}`,el:e,text:t,palette:u(e)}))}return{blocks:o,totalFound:s}}function v(e,t){let n=[],r=[],i=0;for(let a of e){let e=a.text.length;r.length>0&&(r.length>=t.maxItems||i+e>t.maxChars)&&(n.push(r),r=[],i=0),r.push(a),i+=e}return r.length>0&&n.push(r),n}function y(e){let t=2166136261,n=16777619;for(let r=0;r<e.length;r++){let i=e.charCodeAt(r);t^=i,t=Math.imul(t,16777619),n^=i+r,n=Math.imul(n,2246822507)}return`${(t>>>0).toString(16).padStart(8,`0`)}${(n>>>0).toString(16).padStart(8,`0`)}${e.length.toString(16)}`}function b(e,t,n,r){return`tf:cache:${e}:${t}:${n}:${y(r)}`}var x=2592e6;function S(e){return!!(e&&typeof e.text==`string`&&Date.now()-e.ts<x)}async function C(e){let t=new Map;if(e.length===0)return t;let n=e.map(e=>b(e.provider,e.from,e.to,e.text));try{let r=await chrome.storage.local.get(n);e.forEach((e,i)=>{let a=n[i];if(!a)return;let o=r[a];S(o)&&t.set(e.text,o.text)})}catch{}return t}async function w(e,t,n,r){if(r.length===0)return;let i={},a=Date.now();for(let o of r)i[b(e,t,n,o.text)]={text:o.translation,ts:a};try{await chrome.storage.local.set(i)}catch{}}var T=class{minIntervalMs;nextAt=0;constructor(e){this.minIntervalMs=e}async acquire(e){let t=Date.now(),n=Math.max(0,this.nextAt-t);this.nextAt=Math.max(t,this.nextAt)+this.minIntervalMs,n!==0&&await new Promise((t,r)=>{let i=setTimeout(()=>{e?.removeEventListener(`abort`,a),t()},n),a=()=>{clearTimeout(i),r(new DOMException(`Aborted`,`AbortError`))};e?.addEventListener(`abort`,a,{once:!0})})}};async function E(e,t,n){let r=Array(e.length),i=0,a=Array.from({length:Math.max(1,Math.min(t,e.length))},async()=>{for(;i<e.length;){let t=i++;r[t]=await n(e[t],t)}});return await Promise.all(a),r}var D=`tf-style`,O=`tf-block`,k=`
.${O} {
  font-family: inherit;
  font-size: 0.96em;
  line-height: inherit;
  letter-spacing: inherit;
  color: var(--tf-trans-color, #59636f);
  margin: 6px 0 14px;
  padding: 0 0 0 12px;
  border-left: 2px solid var(--tf-rule-color, rgba(15, 118, 110, 0.38));
  contain: content;
  white-space: pre-wrap;
  word-break: break-word;
  animation: tf-in 140ms cubic-bezier(0.2, 0.8, 0.2, 1);
}
.tf-mode-card .${O} {
  background: var(--tf-card-bg, rgba(15, 118, 110, 0.08));
  border-left: 0;
  border-radius: 10px;
  padding: 10px 12px;
}
.tf-mode-mask .${O} {
  filter: blur(4px);
  transition: filter 120ms ease;
  cursor: default;
}
.tf-mode-mask .${O}:hover,
.tf-mode-mask .${O}:focus {
  filter: none;
}
h1 + .${O} { font-size: 0.52em; font-weight: 600; }
h2 + .${O} { font-size: 0.66em; font-weight: 600; }
h3 + .${O} { font-size: 0.82em; }
h4 + .${O}, h5 + .${O}, h6 + .${O} { font-size: 0.9em; }
@keyframes tf-in {
  from { opacity: 0; transform: translateY(2px); }
  to { opacity: 1; transform: translateY(0); }
}
@media (prefers-reduced-motion: reduce) {
  .${O} { animation: none; }
}
`;function A(e=document){if(e.getElementById(D))return;let t=e.createElement(`style`);t.id=D,t.textContent=k,e.documentElement.appendChild(t)}function j(e){let t=e.nextElementSibling;t?.classList.contains(O)&&t.remove()}function M(e,t,n){let{el:r}=e;if(n===`replace`){r.dataset.tfOriginal===void 0&&(r.dataset.tfOriginal=r.textContent??``),r.textContent=t,r.dataset.tfTranslated=`1`;return}j(r);let i=document.createElement(`div`);i.className=O,i.dataset.tfId=e.id,i.dir=`auto`,i.textContent=t,e.palette&&(i.style.setProperty(`--tf-trans-color`,e.palette.trans),i.style.setProperty(`--tf-rule-color`,e.palette.rule),i.style.setProperty(`--tf-card-bg`,e.palette.card)),r.tagName===`TD`||r.tagName===`TH`?r.appendChild(i):r.insertAdjacentElement(`afterend`,i),r.dataset.tfTranslated=`1`}function N(e=document){let t=Array.from(e.querySelectorAll(`.${O}`));for(let e of t)e.remove();let n=0;for(let t of Array.from(e.querySelectorAll(`[data-tf-original]`)))t.textContent=t.dataset.tfOriginal??``,n+=1,delete t.dataset.tfOriginal,delete t.dataset.tfTranslated;for(let t of Array.from(e.querySelectorAll(`[data-tf-translated="1"]`)))delete t.dataset.tfTranslated;return t.length+n}function P(e=document){return e.querySelectorAll(`.${O}`).length}var F=`transflow-root`,I={maxItems:12,maxChars:4e3};function L(){let e=window.getSelection();if(!e||e.isCollapsed||e.rangeCount===0)return null;let t=e.toString().trim();if(t.length<1||t.length>5e3)return null;let n=e.getRangeAt(0).getBoundingClientRect();if(n.width===0&&n.height===0)return null;let r=e.anchorNode;return{text:t,rect:n,el:(r instanceof HTMLElement?r:r?.parentElement)??document.body}}function R(e){let t=e;return t?!!t.closest(`input, textarea, [contenteditable="true"]`):!1}var z=`
  :host { all: initial; }
  * { box-sizing: border-box; }
  .layer { position: fixed; inset: 0; pointer-events: none; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans SC", sans-serif; }
  .trigger {
    position: absolute; width: 22px; height: 22px; border-radius: 50%;
    background: #0F766E; color: #fff; font-size: 11px; line-height: 22px; text-align: center;
    cursor: pointer; pointer-events: auto; box-shadow: 0 2px 8px rgba(0,0,0,.18);
    user-select: none; opacity: 0; transform: translateY(2px); transition: opacity .12s ease, transform .12s ease;
  }
  .trigger.show { opacity: 1; transform: translateY(0); }
  .card {
    position: absolute; width: 340px; max-height: 60vh; overflow: auto;
    background: rgba(255,255,255,.86); backdrop-filter: blur(16px) saturate(1.2);
    border: 1px solid rgba(16,24,40,.08); border-radius: 14px;
    box-shadow: 0 12px 32px rgba(16,24,40,.14); padding: 12px 14px 8px;
    pointer-events: auto; color: #111318;
  }
  @media (prefers-color-scheme: dark) {
    .card { background: rgba(22,25,30,.86); border-color: rgba(255,255,255,.10); color: #F1F4F8; }
    .quote { color: #98A2B3; }
    .meta { color: #6B7684; }
    .row { border-color: rgba(255,255,255,.08); }
  }
  .quote {
    font-size: 11px; line-height: 1.5; color: #667085; margin-bottom: 8px;
    display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
  }
  .divider { height: 1px; background: currentColor; opacity: .08; margin: 0 -14px 9px; }
  .text { font-size: 14px; line-height: 1.6; white-space: pre-wrap; word-break: break-word; min-height: 20px; }
  .row { display: flex; align-items: center; gap: 4px; margin: 8px -14px 0; padding: 6px 10px 2px; border-top: 1px solid rgba(16,24,40,.06); }
  .row button {
    border: 0; background: transparent; font: inherit; font-size: 11.5px; color: inherit; opacity: .72;
    padding: 5px 8px; border-radius: 6px; cursor: pointer;
  }
  .row button:hover { background: rgba(15,118,110,.10); opacity: 1; color: #0F766E; }
  .spacer { flex: 1; }
  .meta { font-size: 10px; opacity: .55; font-variant-numeric: tabular-nums; }
  .skeleton { height: 12px; border-radius: 4px; background: currentColor; opacity: .08; margin: 6px 0; animation: pulse 1.2s ease-in-out infinite; }
  @keyframes pulse { 50% { opacity: .16; } }
  .toast {
    position: fixed; left: 50%; bottom: 28px; transform: translateX(-50%) translateY(8px);
    background: #101828; color: #fff; font-size: 12px; padding: 9px 14px; border-radius: 10px;
    box-shadow: 0 8px 24px rgba(0,0,0,.2); opacity: 0; transition: opacity .2s ease, transform .2s ease;
    pointer-events: none; max-width: 70vw;
  }
  .toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }
  .ambient {
    position: fixed; top: 0; left: 0; right: 0; height: 28px; display: flex; align-items: center; gap: 10px;
    padding: 0 12px; font-size: 11px; color: #0B5F59; background: rgba(15,118,110,.07);
    border-bottom: 1px solid rgba(15,118,110,.14); backdrop-filter: blur(8px);
    transform: translateY(-100%); transition: transform .18s ease; pointer-events: none; z-index: 5;
  }
  .ambient.show { transform: translateY(0); }
  .amb-mark { font-weight: 700; }
  .amb-text { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .amb-bar { width: 72px; height: 2px; border-radius: 2px; background: rgba(15,118,110,.18); overflow: hidden; flex: none; }
  .amb-bar i { display: block; height: 100%; width: 0; background: #0F766E; border-radius: 2px; transition: width .24s ease; }
  .amb-pct { font-variant-numeric: tabular-nums; opacity: .7; }
  .amb-spacer { flex: 1; }
  .amb-btn {
    pointer-events: auto; border: 0; background: transparent; color: #0B5F59; font: inherit; font-size: 11px;
    padding: 4px 8px; border-radius: 6px; cursor: pointer;
  }
  .amb-btn:hover { background: rgba(15,118,110,.12); }
  .ambient.dark { color: #7FE7D6; background: rgba(45,212,191,.08); border-bottom-color: rgba(45,212,191,.16); }
  .ambient.dark .amb-bar { background: rgba(45,212,191,.2); }
  .ambient.dark .amb-bar i { background: #2DD4BF; }
  .ambient.dark .amb-btn { color: #7FE7D6; }
  @media (prefers-reduced-motion: reduce) {
    .ambient, .card, .trigger, .toast { transition: none; }
  }
`;function B(){let e=document.getElementById(F);if(e)return e.shadowRoot;e=document.createElement(`div`),e.id=F,e.style.cssText=`position:fixed;inset:0;z-index:2147483000;pointer-events:none;`;let t=e.attachShadow({mode:`closed`}),n=document.createElement(`style`);n.textContent=z;let r=document.createElement(`div`);return r.className=`layer`,t.append(n,r),document.documentElement.appendChild(e),t}function V(e){return e.querySelector(`.layer`)}var H=e({matches:[`<all_urls>`],runAt:`document_idle`,allFrames:!1,main(){let e=B(),t=document.getElementById(F),n=V(e),r=null,i=null,a=null,o=null,s=null,c=()=>r?.classList.remove(`show`),l=()=>{i?.remove(),i=null},f=e=>{let t=n.querySelector(`.toast`);t||(t=document.createElement(`div`),t.className=`toast`,n.appendChild(t)),t.textContent=e,requestAnimationFrame(()=>t?.classList.add(`show`)),a&&window.clearTimeout(a),a=window.setTimeout(()=>t?.classList.remove(`show`),2600)},p=async()=>{let e=await chrome.runtime.sendMessage({type:`get-settings`});if(!e.ok)throw Error(e.error.message);return e.data},m=async(e,t,n)=>await chrome.runtime.sendMessage({type:`translate`,segments:e,from:t,to:n}),h=(e,t)=>{let n=e.getBoundingClientRect(),r=n.width||340,i=n.height||180,a=Math.min(Math.max(8,t.left),window.innerWidth-r-8),o=t.bottom+8;o+i>window.innerHeight-8&&(o=t.top-i-8),o<8&&(o=8,e.style.maxHeight=`${window.innerHeight-16}px`),e.style.left=`${a}px`,e.style.top=`${o}px`},g=(e,t)=>{e.style.background=`color-mix(in srgb, ${t.bg} 88%, transparent)`,e.style.color=t.fg,e.style.borderColor=`color-mix(in srgb, ${t.fg} 12%, transparent)`;let n=e.querySelector(`.quote`);n&&(n.style.color=t.trans);let r=e.querySelector(`.divider`);r&&(r.style.background=`color-mix(in srgb, ${t.fg} 10%, transparent)`);let i=e.querySelector(`.row`);i&&(i.style.borderTopColor=`color-mix(in srgb, ${t.fg} 8%, transparent)`)},y=async(e,t,r)=>{l(),c();let a=t;(t.bottom<0||t.top>window.innerHeight)&&(r.scrollIntoView({block:`center`}),a=r.getBoundingClientRect()),i=document.createElement(`div`),i.className=`card`,i.innerHTML=`
        <div class="quote"></div>
        <div class="divider"></div>
        <div class="text"><div class="skeleton" style="width:88%"></div><div class="skeleton" style="width:64%"></div></div>
        <div class="row"><button data-act="copy">复制</button><button data-act="close">关闭</button><span class="spacer"></span><span class="meta">翻译中…</span></div>
      `,i.querySelector(`.quote`).textContent=e,g(i,u(r)),n.appendChild(i),h(i,a);try{let t=await p().catch(()=>null),n=t?.selection.target||t?.language.target||`zh`,r=await m([{id:`selection`,text:e}],`auto`,n);if(!i)return;let a=i.querySelector(`.text`),o=i.querySelector(`.meta`);if(!r.ok){a.textContent=r.error.message,o.textContent=`失败`;return}let s=r.data.results[0]?.text??``;a.textContent=s,o.textContent=`${r.data.provider} · ${r.data.latencyMs} ms`,i.querySelector(`[data-act="copy"]`)?.addEventListener(`click`,async()=>{await navigator.clipboard.writeText(s),o.textContent=`已复制`}),i.querySelector(`[data-act="close"]`)?.addEventListener(`click`,l)}catch(e){if(!i)return;i.querySelector(`.text`).textContent=`翻译失败：${e.message}`}},b=e=>{r||(r=document.createElement(`button`),r.className=`trigger`,r.textContent=`译`,r.title=`翻译选中文本`,r.addEventListener(`mousedown`,e=>e.preventDefault()),r.addEventListener(`click`,()=>{let e=L();e&&y(e.text,e.rect,e.el)}),n.appendChild(r)),r.style.left=`${Math.min(e.rect.right+6,window.innerWidth-30)}px`,r.style.top=`${Math.min(e.rect.bottom+6,window.innerHeight-30)}px`,requestAnimationFrame(()=>r?.classList.add(`show`))},x=()=>o||(o=document.createElement(`div`),o.className=`ambient`,o.innerHTML=`
        <span class="amb-mark">译流</span>
        <span class="amb-text"></span>
        <span class="amb-bar"><i></i></span>
        <span class="amb-pct"></span>
        <span class="amb-spacer"></span>
        <button class="amb-btn"></button>
      `,n.appendChild(o),o),S=(e,t,n,r)=>{let i=x();i.classList.toggle(`dark`,document.documentElement.classList.contains(`tf-dark`)),i.querySelector(`.amb-text`).textContent=e,i.querySelector(`.amb-pct`).textContent=`${Math.round(t)}%`,i.querySelector(`.amb-bar i`).style.width=`${Math.max(0,Math.min(100,t))}%`;let a=i.querySelector(`.amb-btn`);a.textContent=n,a.onclick=r,requestAnimationFrame(()=>i.classList.add(`show`))},D=(e=0)=>{o&&window.setTimeout(()=>{o?.classList.remove(`show`)},e)},O=()=>{if(!s)return;s.controller.abort(),s.active=!1;let e=s.done;S(`已停止 · 保留 ${e} 段`,100,`还原`,k),D(5e3)},k=()=>{s?.controller.abort();let e=N();s=null,D(),f(e>0?`已还原原文`:`没有可还原的内容`)},j=async()=>{if(s?.active){f(`正在翻译中…`);return}if(P()>0){f(`页面已翻译，请先还原`);return}let e;try{e=await p()}catch(e){f(e.message);return}let t=e.page.mode,n=e.language.target||`zh`,r=e.language.source||`auto`,{blocks:i,totalFound:a}=_({maxSegments:e.page.maxSegments});if(i.length===0){f(`页面中没有可翻译的内容`);return}A(),d(u(document.body),t);let o=new Map;for(let e of i){let t=o.get(e.text);t?t.push(e):o.set(e.text,[e])}let c=Array.from(o.keys()).map((e,t)=>({id:`s${t}`,text:e})),l={controller:new AbortController,refs:o,total:c.length,done:0,failed:0,active:!0};s=l;let h=performance.now();S(`正在翻译 · 0/${c.length} 段`,0,`取消`,O);let g=e.provider.active,y=await C(c.map(e=>({provider:g,from:r,to:n,text:e.text}))),b=[];for(let e of c){let n=y.get(e.text);if(n===void 0)b.push(e);else{for(let r of o.get(e.text)??[])M(r,n,t);l.done+=1}}l.done>0&&S(`正在翻译 · ${l.done}/${l.total} 段`,l.done/l.total*100,`取消`,O);let x=new T(120);if(await E(v(b,I),2,async e=>{if(!l.controller.signal.aborted)try{await x.acquire(l.controller.signal);let i=await m(e,r,n);if(l.controller.signal.aborted)return;if(!i.ok){l.failed+=e.length;return}let a=[];for(let n of i.data.results){let r=e.find(e=>e.id===n.id);if(r){for(let e of o.get(r.text)??[])M(e,n.text,t);a.push({text:r.text,translation:n.text}),l.done+=1}}await w(g,r,n,a)}catch(t){if(t.name===`AbortError`)return;l.failed+=e.length}finally{l.controller.signal.aborted||S(`正在翻译 · ${l.done}/${l.total} 段`,l.done/l.total*100,`取消`,O)}}),l.controller.signal.aborted)return;l.active=!1;let j=((performance.now()-h)/1e3).toFixed(1),N=l.failed>0?`完成 ${l.done} 段，${l.failed} 段失败`:`已翻译 ${l.done} 段 · ${j}s`;S(N,100,`还原`,k),D(8e3),a>i.length&&f(`内容较多，已翻译前 ${i.length} 段`)},z=e=>{let t=e;if(!t)return null;if(t instanceof HTMLTextAreaElement)return t;if(t instanceof HTMLInputElement){let e=t.type.toLowerCase();return[`text`,`search`,`url`,`email`,`tel`].includes(e)?t:null}return t.isContentEditable?t:null},H=e=>e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?e.value:e.innerText.replace(/\u00a0/g,` `),U=(e,t)=>{if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){let n=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;(Object.getOwnPropertyDescriptor(n,`value`)?.set)?.call(e,t)}else e.textContent=t;e.dispatchEvent(new InputEvent(`input`,{bubbles:!0,inputType:`insertText`,data:t}))},W=null,G=0,K=null,q=async e=>{if(!e){f(`请先聚焦一个输入框`);return}let t=H(e).trim();if(t.length<2)return;if(t.length>5e3){f(`输入内容超过 5000 字`);return}let n=await p().catch(()=>null),r=n?.selection.target||n?.language.target||`zh`;f(`翻译中…`);try{let n=await m([{id:`input`,text:t}],`auto`,r);if(!n.ok){f(`翻译失败：${n.error.message}`);return}let i=n.data.results[0]?.text??``;if(!i)return;W={el:e,original:H(e),at:Date.now()},U(e,i),f(`已翻译 · ⌘Z 撤销`)}catch(e){f(`翻译失败：${e.message}`)}};document.addEventListener(`keydown`,e=>{let t=z(e.target);if(t&&(e.metaKey||e.ctrlKey)&&e.key.toLowerCase()===`z`&&W&&W.el===t&&Date.now()-W.at<1e4)e.preventDefault(),U(t,W.original),W=null,f(`已撤销`);else if(e.key===` `&&t){let n=Date.now();if(K===t&&n-G<400){e.preventDefault(),G=0,K=null,q(t);return}G=n,K=t}}),document.addEventListener(`mouseup`,e=>{R(e.target)||window.setTimeout(()=>{let e=L();e?b(e):c()},100)}),document.addEventListener(`mousedown`,e=>{e.composedPath().some(e=>e===t||e===n||e===r||e===i)||(c(),l())}),document.addEventListener(`keydown`,e=>{e.key===`Escape`&&(c(),l())});try{chrome.runtime.sendMessage({type:`ping`})}catch{}chrome.runtime.onMessage.addListener((e,t,n)=>((async()=>{if(e.type===`selection-translate`){let e=L();e?await y(e.text,e.rect,e.el):f(`请先选中要翻译的文本`),n({ok:!0,data:null})}else e.type===`page-translate`?(await j(),n({ok:!0,data:null})):e.type===`page-restore`?(k(),n({ok:!0,data:null})):e.type===`input-translate`?(await q(z(document.activeElement)),n({ok:!0,data:null})):e.type===`get-selection`?n({ok:!0,data:{text:window.getSelection()?.toString().trim()??``}}):n({ok:!1,error:{code:`unknown`,message:`未知操作`}})})(),!0))}}),U={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},W=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,G=class e extends Event{static EVENT_NAME=K(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function K(e){return`${W?.runtime?.id}:content:${e}`}var q=typeof globalThis.navigation?.addEventListener==`function`;function J(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),q?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new G(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new G(e,t)),t=e)},1e3))}}}var Y=class e{static SCRIPT_STARTED_MESSAGE_TYPE=K(`wxt:content-script-started`);id;abortController;locationWatcher=J(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return W.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?K(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),U.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},X={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=H;return await e(new Y(`content`,t))}catch(e){throw X.error(`The content script "content" crashed on startup!`,e),e}})()})();